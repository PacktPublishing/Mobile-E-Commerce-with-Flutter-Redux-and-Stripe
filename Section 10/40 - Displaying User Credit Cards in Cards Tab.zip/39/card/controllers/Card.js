"use strict";

const stripe = require("stripe")("YOUR_STRIPE_SECRET_KEY");

/**
 * A set of functions called "actions" for `Card`
 */

module.exports = {
  index: async ctx => {
    const customerId = ctx.request.querystring;
    const customerData = await stripe.customers.retrieve(customerId);
    const cardData = customerData.sources.data;
    ctx.send(cardData);
    // ctx.send("hello world");
  }
};
